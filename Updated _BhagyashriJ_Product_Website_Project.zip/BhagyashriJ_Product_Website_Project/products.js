const products = [
    {
      id: 0,
      name: "Mahindra Thar 1",
      price: "14.28",
      instock: 20,
      description:
        "<b> Engine: </b>  1997 cc <br> <b> Fuel Type: </b>  Petrol <br> <b> Transmission: </b>  Manual <br>  <b> Seating Capacity: </b>  4 Seater <br> <br>  ",
      imgSrc: "./assets/images/Mahindra_Thar_Photoshoot_At_Perupalem_Beach_(West_Godavari_District,AP,India_)_Djdavid.jpg",
    },
    {
      id: 1,
      name: "Mahindra Thar 2",
      price: "16.28",
      instock: 3,
      description:
      "<b> Engine: </b>  1997 cc <br> <b> Fuel Type: </b>  Petrol <br> <b> Transmission: </b>  Manual <br>  <b> Seating Capacity: </b>  4 Seater <br> <br> ",
      imgSrc: "./assets/images/y.jfif",
    },
    {
      id: 2,
      name: "Mahindra Thar 3",
      price: "13.53",
      instock: 10,
      description:
      "<b> Engine: </b>  1997 cc <br> <b> Fuel Type: </b>  Petrol <br> <b> Transmission: </b>  Manual <br>  <b> Seating Capacity: </b>  4 Seater <br> <br> ",
      imgSrc: "./assets/images/red.jfif",
    },
    {
      id: 3,
      name: "Mahindra Thar 4",
      price: "15.28",
      instock: 5,
      description:
      "<b> Engine: </b>  1997 cc <br> <b> Fuel Type: </b>  Petrol <br> <b> Transmission: </b>  Manual <br>  <b> Seating Capacity: </b>  4 Seater <br> <br> ",
      imgSrc: "./assets/images/blue.jfif",
    },

  ];
  